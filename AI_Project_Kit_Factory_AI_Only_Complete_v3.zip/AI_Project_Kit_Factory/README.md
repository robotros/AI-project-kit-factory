# AI Project Kit Factory — AI-Only v3.0

Design, create, deploy, and validate reusable **AI project and agent kits** using only natural-language conversations and Markdown. No Python, scripts, APIs, terminal, web forms, or coding skills are required.

## What it produces

From ONE brief, the Factory produces **two complete editions** for every requested role/project:

| Item | Light — resource-conscious / Free | Full — enhanced / Paid |
|---|---|---|
| Project/agent instruction text | `PROJECT_INSTRUCTIONS.txt`, max 7,500 characters | `PROJECT_INSTRUCTIONS.txt`, max 7,500 characters |
| Knowledge/reference uploads | Exactly **3** `.md` files | Exactly **8** `.md` files |
| Project types | Single or multi-role, manual handoffs | Single or multi-role, detailed handoffs and governance |
| Prompt library | Starter, recurring task, troubleshooting, QA prompts | Optimized prompts including variations, edge cases, adversarial and regression checks |
| Validation | AI-run artifact checks + user-confirmed setup | AI-run artifact checks + structured test suite, release gate, receipts |
| Setup | Create in target app if a supported, authorized tool can; otherwise guide user | Same, with optional authorized agent-assisted actions |

The Factory supports ChatGPT Projects, Claude Projects, Gemini Skills/Gems, and Grok Skills/Bots or a reusable chat fallback. It chooses by the CURRENT interface and actual account capabilities, **never** assumes access or manufactures success. The word “Project” in the Factory is a logical work unit and may become a skill, Gem, bot, or dedicated chat on the target platform.

**Separation of purpose:** `light/` and `full/` are versions of the Factory itself. When used, each version produces both Light and Full editions of the destination kit by default. The Light Factory has fewer reference files; it does not suppress the paid target edition.

## Quick start (no code)

1. Pick `light/` (3 reference `.md` files) or `full/` (8 reference `.md` files).
2. In your chosen AI platform, create an appropriate persistent workspace or reusable assistant if supported; otherwise start a new chat. See `QUICK_START.md` and `docs/PLATFORM_GUIDE.md`.
3. Paste `PROJECT_INSTRUCTIONS.txt` into the platform's dedicated instruction field. If no such field exists, paste it as the first message and ask the model to treat it as the operating charter within that conversation. **Do not** assume this makes it persistent across chats.
4. Upload or paste the selected edition's `.md` knowledge files. If the app does not accept `.md`, paste the contents as text. Follow platform-specific constraints and actual current plan limits.
5. Send the starter prompt from `START_HERE.md`. Let the AI gather minimum requirements and build **both** destination editions unless you explicitly request one.
6. Run `/setup` to attempt authorized installation and `/validate` to test the artifacts plus the actual installed configuration. Check the receipt before declaring completion.

## Commands to use in natural language

`/new-kit` — intake, architecture, both editions, installation files and optimized prompts.

`/setup` — capability check, permission gate, automatic creation if truly enabled, otherwise platform-specific guided setup.

`/validate` — lint the text and files; exercise sample tasks; verify installation by evidence; issue pass/fail/needs-verification report.

`/revise` — update requirements, propagate changes to all projects and both editions, then revalidate.

`/convert` — adapt an existing kit to another supported platform without silently changing its requirements.

Commands are **plain-language conventions**, not software slash commands; just type them.

## Repository layout

- `light/` and `full/`: installable Factory editions (instructions plus 3 or 8 knowledge files)
- `START_HERE.md`: universal AI-guided setup prompt
- `QUICK_START.md`: installation steps with self-check
- `docs/`: platform guidance, generated output contract, security, and version notes
- `prompts/`: reusable optimized prompt patterns and setup/test dialogue
- `templates/`: blank Markdown templates to instantiate (not a sample project kit)

**No generated sample project kit is included. No scripts, Python, HTML form, package installer, or CI dependency is included.**

## How to interpret validation

The AI can automatically check text it can see, compare manifest entries, run role-play test inputs, and report failures. It **cannot** verify that another app created a project or saved its settings unless it has inspected that app using an authorized tool or the user supplies confirmation/evidence. A pass on AI-only checks is not an audited security guarantee.

The supported-app surface and limits change. Treat the provider links in `docs/PLATFORM_GUIDE.md` as live references, not immutable capabilities. Last researched: 2026-10-17.
