# AI Project Kit Factory Full v1.4.2 — Standalone installer

**Edition:** Factory Full, exactly 8 canonical Markdown knowledge uploads in `factory-full/`, plus `FACTORY_INSTRUCTIONS_FULL.txt` for the instruction field. **License:** MIT, Copyright (c) 2026 robotros. **Files:** 53, this manifest included. **SHA-256 entries:** 52 (excludes manifest).

These kit-level setup, community and guidance files are not additional Project knowledge uploads. The Factory generates BOTH specialist Light (3) and Full (8) editions per role. A ZIP is not a deployed Project or published release.

| File | SHA-256 |
|---|---|
| `.github/ISSUE_TEMPLATE/bug_report.yml` | `d1e292f12795f306e6a8464922734a1ab893ba0feaa49afa25304173a008be96` |
| `.github/ISSUE_TEMPLATE/feature_request.yml` | `4267441479278a42452422a7bb977a212866ebac1da9e9880086e77357e63a6a` |
| `.github/PULL_REQUEST_TEMPLATE.md` | `f98e49ad9abad6baa419588576522a957940bf8139ad31dc9604e1e1fc465506` |
| `AI_SETUP_PROMPT.md` | `8e7474ecb036c0b28cb613c1ff1d33e661ff586c9a2ae8998258be6cdf42e685` |
| `CODE_OF_CONDUCT.md` | `72569174c0b6c7c2736519c9d58425e4586d50f01106c30ad193ee157b8396d1` |
| `CONTRIBUTING.md` | `3b04172ddc7a9f7fae5b7fc05e0c7d1f17a40f84019bfc04ace8b0270f7099c5` |
| `GITHUB_RELEASE_v1.4.2.md` | `26631b6e1fb8aa440805e5f3ff5c9846851bd3b1f6585f4cfc9e0a6ae11a8c06` |
| `LICENSE` | `43554d1189d8bcf4081bb57ef1481c6917d3be0b71cf5a926204e77b61056e62` |
| `README.md` | `82b40f670f5c046d2bf778625af52207426f602cf219a6b58cc0540ba0453b1b` |
| `SECURITY.md` | `b34dbb8627cd3b33af77c8db326a316d3e924ae3a1583a02f0e99760c5036a11` |
| `START_HERE.md` | `e909a1a40335d63c225896e7f2b7856190b079fdfe9b9ed8888957c0f7ecf898` |
| `VALIDATION_REPORT.md` | `20a978c263f5331efa3c8f81a9cc7028e8d15307b4ec7eb5cdad33bde677ca0c` |
| `adapters/microsoft-365-agent-builder/full/01_FACTORY_CHARTER.txt` | `065730bb0d58ff04a02a1386f051d031ba3b8fa3ef5ef2e5fd1b888902db7943` |
| `adapters/microsoft-365-agent-builder/full/02_DISCOVERY_AND_ARCHITECTURE.txt` | `c6560ad81780afa87e0dd76a9c976de33cbf8b86c5819ef323fda19308f9546d` |
| `adapters/microsoft-365-agent-builder/full/03_PLATFORM_PROFILES.txt` | `f469548a7da5917582604fe27bcfb555a026f3518df82b018e6a680b29c1cb1c` |
| `adapters/microsoft-365-agent-builder/full/04_GENERATION_STANDARDS.txt` | `704c6c348c2743bac14dd69aa79ea9b03de74460803b77c4384bdea326ffde5b` |
| `adapters/microsoft-365-agent-builder/full/05_PROMPT_ENGINEERING.txt` | `7a8a0cde790a7490767583e7c2dccb697bfb1acb9dd466fa0ab29aaad55eb41e` |
| `adapters/microsoft-365-agent-builder/full/06_SETUP_ORCHESTRATION.txt` | `7e0599eb1f08a04d9c18e06385fdb71ec4d475c2bf72d61ce48916b88e623a22` |
| `adapters/microsoft-365-agent-builder/full/07_VALIDATION_AND_EVALS.txt` | `d520b87ec19564556b4b2763e7beb9c4eda76767355e393953cfd082a776a70a` |
| `adapters/microsoft-365-agent-builder/full/08_GOVERNANCE_AND_UPDATES.txt` | `6e44f4acf89b2a113abce9ee991592007f78dcb09f38dac4d4e5a4a3758f7170` |
| `docs/CAPABILITY_MATRIX.md` | `62279d746417d932d1dd181b5683153a8088371eac77e8062a82da8aeec21aa6` |
| `docs/CLAUDE_PLATFORM_GUIDE.md` | `8a630fbb1f7a8eff59ee859f350d8c12a965d02fdb29997afc8b75b309d5a23a` |
| `docs/GENERATED_KIT_GITHUB_OPTIONS.md` | `41a5ab01fe517febf5f85281dcf072b512d494a8954e259536d4a43515bb33de` |
| `docs/MICROSOFT_PLATFORM_GUIDE.md` | `023f3f418e87c87a3f24669bbcfcf738f8eaa4b1d7b2e37a541ecb32033dbaed` |
| `docs/OFFICIAL_SOURCES.md` | `4bcef5f379bc28bc4d2e22127c7e0de108814d00122334f97ab54ef79876a7a8` |
| `docs/SKILL_PACKAGING_AND_ARCHITECTURE.md` | `4f6efe7c31c09d3ddde7bc6bb0aac9fa76dcc1be93fa4c12e1beece9375dbc12` |
| `factory-full/01_FACTORY_CHARTER.md` | `065730bb0d58ff04a02a1386f051d031ba3b8fa3ef5ef2e5fd1b888902db7943` |
| `factory-full/02_DISCOVERY_AND_ARCHITECTURE.md` | `c6560ad81780afa87e0dd76a9c976de33cbf8b86c5819ef323fda19308f9546d` |
| `factory-full/03_PLATFORM_PROFILES.md` | `f469548a7da5917582604fe27bcfb555a026f3518df82b018e6a680b29c1cb1c` |
| `factory-full/04_GENERATION_STANDARDS.md` | `704c6c348c2743bac14dd69aa79ea9b03de74460803b77c4384bdea326ffde5b` |
| `factory-full/05_PROMPT_ENGINEERING.md` | `7a8a0cde790a7490767583e7c2dccb697bfb1acb9dd466fa0ab29aaad55eb41e` |
| `factory-full/06_SETUP_ORCHESTRATION.md` | `7e0599eb1f08a04d9c18e06385fdb71ec4d475c2bf72d61ce48916b88e623a22` |
| `factory-full/07_VALIDATION_AND_EVALS.md` | `d520b87ec19564556b4b2763e7beb9c4eda76767355e393953cfd082a776a70a` |
| `factory-full/08_GOVERNANCE_AND_UPDATES.md` | `6e44f4acf89b2a113abce9ee991592007f78dcb09f38dac4d4e5a4a3758f7170` |
| `factory-full/FACTORY_INSTRUCTIONS_FULL.txt` | `bad225200b5feea8020eb94510e2c87ef2b2f7ccb873d2e3eb4c7f95e0b4cdda` |
| `setup/CHATGPT_INSTALLATION.md` | `d3ae4020f4c36b64923f9180bd13e53e3bf255cd9361e250eced66f981d1074a` |
| `setup/CLAUDE_INSTALLATION.md` | `90e60a34baf13b84b7d4736ec39b561954ebec908854171bb1acf4f4cd55cc76` |
| `setup/CLAUDE_TEST_PROMPTS.md` | `dcd33ce61103d1e0c68f6d3482bb95f2f35ff9b06a802dff2cddc8cfd4b121fb` |
| `setup/CROSS_PLATFORM_INSTALLATION.md` | `1e01bfb4d543b58b9f1243fa018e6e2a8af94a3a82f2bc56ee0945fb030fcf93` |
| `setup/CROSS_PLATFORM_TEST_PROMPTS.md` | `c07d0cb6a2a5a7b46e2ecfe6a9dfa68a4c80918da2c97b50fce3953f4d50ef71` |
| `setup/DEPLOYMENT_RECEIPT.md` | `2b15cdc0e3048980a3ecaa532da17b90545cbddd2ea67eba868fb05a427bd3e9` |
| `setup/EDITION_SELECTION_AND_MIGRATION.md` | `ac9755d6669e6c5eca19f1da09a5a3045ef79e7521a8db20dfd0e1ef74a65c5f` |
| `setup/FACTORY_AGENT_INSTRUCTIONS_MICROSOFT.txt` | `99137f129be350623e7490c3479e777f00245047869308dc528ec29e2994908d` |
| `setup/FACTORY_PROJECT_INSTRUCTIONS_ADDENDUM.txt` | `c27a6f669062e9314859349ff877c4d50b1666cc06b86eb299e9ede9022a7251` |
| `setup/GEMINI_INSTALLATION.md` | `9501d5a9d9371a627960385ecaa128607517b66dc1dd2ab383bf60c411fdde47` |
| `setup/GITHUB_PUBLISHING.md` | `04578a882058903d670dd733cf44da96dc7d51ac630bf85737fc03acd8c437f6` |
| `setup/GROK_INSTALLATION.md` | `b4dae7f4c5d1d8d8f3ea911a0ea24f626aaf62a562da204b9d44c1fc57762556` |
| `setup/INSTALL_CHECKLIST.md` | `25bc4260e68aaa17ee12c7088df5f4ed524356fa1abf15f83561d6280a40b9ff` |
| `setup/INSTALL_WIZARD_TESTS.md` | `799f6f96abebdec2a131a86cb8ad34598772fb185329e6a2f90a293b0e4332db` |
| `setup/MICROSOFT_INSTALLATION.md` | `cb299d1898bd7092a99eecdaa9b0b58d0c7c8a6be09692fe66a1b9c34b2631df` |
| `setup/PLATFORM_INSTALLATION.md` | `36c632623b4357a53f42bb019b24e7a662aca077f1f801ca1960df35c90775eb` |
| `setup/QUICK_PLATFORM_MATRIX.md` | `4e3022599362777537f53c7def60924c20873de4dc31edf53940b6adaf2859a0` |
