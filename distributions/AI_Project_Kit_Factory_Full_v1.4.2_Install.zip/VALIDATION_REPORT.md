# Factory Full v1.4.2 — Installer validation

**Result:** STATIC PASS for correct Full (8 Markdown) knowledge and approved MIT notice. All files were obtained from the verified v1.4.2 release branch source; installation in a ChatGPT/Claude/Microsoft account is NOT claimed. Owner must inspect uploaded instructions and eight saved file names in a fresh Project chat, run missing facts, source injection, unauthorized writes and dual specialist Light/Full tests. Native Skills are separate archives.
