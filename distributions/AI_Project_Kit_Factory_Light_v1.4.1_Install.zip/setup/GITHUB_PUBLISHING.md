# GitHub publishing and MIT release — Factory v1.4.1

**Verified repository:** https://github.com/robotros/AI-project-kit-factory  
**Previously verified release:** `v1.4.0`  
**New release target:** `v1.4.1` (not claimed published until verified)  
**License:** [MIT](../LICENSE); copyright (c) 2026 robotros.

## Existing-repository update (manual, no CLI)

1. Owner reviews `CHANGELOG.md`, `GITHUB_RELEASE_v1.4.1.md`, and [MIT license](../LICENSE). MIT is a permissive grant; ensure you intend the licensing terms for these original Factory materials.
2. In GitHub, open the existing repository above. Back up or bookmark the existing `v1.4.0` release and compare current paths before replacing.
3. Update the existing files using the v1.4.1 repository ZIP **contents**, preserving folder paths. Add `LICENSE` and new release notes; replace renamed v1.4 distribution ZIPs with their v1.4.1 counterparts. Remove obsolete binaries only after verifying the new artifacts (leave earlier Git tags/releases intact).
4. Review changes carefully and commit. Confirm the README links, MIT license detection, edition instructions, 3/8 reference files, hashes, and all six distributions.
5. Choose **Releases → Draft a new release**; create `v1.4.1` on the verified commit, then copy the Markdown text from `GITHUB_RELEASE_v1.4.1.md` into the release description.
6. Attach the main repository ZIP and optionally the two independent installation ZIPs. Verify published tag, release notes, release asset availability, and downloads by opening them in a new session.

**Do not claim** that assembling the package publishes a GitHub release. Repo-writing actions require owner approval; a GitHub ZIP is not an installed AI agent. Skills and Project deployments require separate setup and live validation.

## Publishing through an authorized GitHub integration

Where the owner has explicitly authorized a GitHub connector to write, stage versioned modifications on a dedicated branch for review first, check its diff, then merge with approval. Not every connector can create GitHub releases or upload release assets; if not available, complete those actions in the GitHub UI. Never pretend a release exists without a successful API response and follow-up readback.
