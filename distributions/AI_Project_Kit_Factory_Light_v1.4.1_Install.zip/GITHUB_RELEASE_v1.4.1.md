# AI Project Kit Factory v1.4.1 — MIT-Licensed Cross-Platform Release

**Release target:** `v1.4.1`  
**Repository:** https://github.com/robotros/AI-project-kit-factory  
**License:** [MIT](https://github.com/robotros/AI-project-kit-factory/blob/main/LICENSE) — Copyright (c) 2026 robotros  
**Release date:** October 20, 2026

## Overview

v1.4.1 is a maintenance and licensing release of AI Project Kit Factory v1.4. It makes the licensing and sharing rules explicit, brings GitHub documentation into alignment with the live repository, and refreshes versioned installer/Skill distribution archives.

## Changes since v1.4.0

- Added the standard MIT `LICENSE` file, including the required copyright and redistribution notice.
- Updated README, start guide, manifest, GitHub publication guide, and factory governance text to reflect MIT licensing and the verified repository URL.
- Clarified the distinction between a **generated ZIP**, a **GitHub commit/tag/release**, and a **verified installation or Skill activation**.
- Versioned the Light and Full Factory instruction files and reference materials to `v1.4.1`.
- Rebuilt separate **Factory Light** (3 knowledge files) and **Factory Full** (8 knowledge files) installers with the MIT notice.
- Rebuilt Light/Full Claude-wrapped and root-import Skill ZIPs with MIT notice and version-matched references.
- Regenerated the SHA-256 manifest and static-validation report.

## Contents

| Edition | Factory knowledge uploads | Factory instructions | Generates |
|---|---:|---|---|
| Light | 3 Markdown files | `factory-light/FACTORY_INSTRUCTIONS_LIGHT.txt` | Both specialist Light (3 files) and Full (8 files) kits |
| Full | 8 Markdown files | `factory-full/FACTORY_INSTRUCTIONS_FULL.txt` | Both specialist Light (3 files) and Full (8 files) kits |

Both editions include six command shortcuts: `/new-kit`, `/deliver`, `/setup`, `/validate`, `/revise`, `/convert`. The guided wizard supports ChatGPT, Claude, Gemini, Grok, Microsoft 365 Copilot, and Copilot Studio subject to actual platform/plan capability checks. Optional reusable Skills are provided as standalone archives; they never automatically inherit Project state or external-service permissions.

## Installation

1. Start with [`START_HERE.md`](https://github.com/robotros/AI-project-kit-factory/blob/main/START_HERE.md) to select an edition.
2. For a conversation-led setup use [`AI_SETUP_PROMPT.md`](https://github.com/robotros/AI-project-kit-factory/blob/main/AI_SETUP_PROMPT.md). For manual setup use the platform guide in `setup/`.
3. Upload **only** the 3 Light or 8 Full Factory knowledge references, paired with the matching instruction text.
4. Install a compatible Skill only if the destination actually supports it; test both activation and non-activation.
5. Follow [`setup/EDITION_SELECTION_AND_MIGRATION.md`](https://github.com/robotros/AI-project-kit-factory/blob/main/setup/EDITION_SELECTION_AND_MIGRATION.md) for upgrades and rollback.

## Verification

Read [`VALIDATION_REPORT.md`](https://github.com/robotros/AI-project-kit-factory/blob/main/VALIDATION_REPORT.md) for the local integrity checks, instruction budgets, file/reference parity, and the distinction between static versus live tests. **Live AI-platform installation and behavior are not verified by the ZIP alone.** The GitHub `v1.4.1` release is not claimed published until separately confirmed on the repository.

## License and attribution

Original Factory files are distributed under the [MIT License](LICENSE). Include the copyright and permission notices in substantial redistributed copies; third-party product names and marks belong to their respective owners. This release does not grant rights to third-party services or data.
