# Factory Light v1.4 standalone installer manifest

Every path is relative to this installer archive root. The manifest excludes its own hash.

- `AI_SETUP_PROMPT.md` — `f6bb74b41a5c83b6942178ac362fd1fec358a71f79565e444a350a547260dc10`
- `README.md` — `20270993cf208576a4aee19a9d6fcaf940bca7641df2a19730b06ae99f044128`
- `adapters/microsoft-365-agent-builder/light/01_CHARTER_AND_DISCOVERY.txt` — `aae60bad9cc6eba81d9ad2ca8d1b900ec9966d984eec0116ecbcef0b2534926a`
- `adapters/microsoft-365-agent-builder/light/02_PLATFORMS_GENERATION_AND_SETUP.txt` — `371a57f04ec54677838b7f4ff3aeb516c8541f53140b2a6a29dd353de528a116`
- `adapters/microsoft-365-agent-builder/light/03_GOVERNANCE_VALIDATION_AND_UPDATES.txt` — `e424605d9fcd714185991577b4b562994864ded4fa9ef6febb7a30c662997db5`
- `distributions/AI_Project_Kit_Factory_Light_Claude_Skill_v1.4.zip` — `f8073cd516ca854d7241d25c3e0cbe7ffb4f44ff5cf17ca8b74f62737b30dd57`
- `distributions/AI_Project_Kit_Factory_Light_Root_Skill_v1.4.zip` — `321112ccdcdf7835850da0767e399b68821dae5a066f01c9ee4b4a03a1d65aa1`
- `docs/OFFICIAL_SOURCES.md` — `b600e840854474b12bef944eea0a9776cd2f1d944fd4f91ba8eaedbc0d8be4c5`
- `factory-light/01_CHARTER_AND_DISCOVERY.md` — `aae60bad9cc6eba81d9ad2ca8d1b900ec9966d984eec0116ecbcef0b2534926a`
- `factory-light/02_PLATFORMS_GENERATION_AND_SETUP.md` — `371a57f04ec54677838b7f4ff3aeb516c8541f53140b2a6a29dd353de528a116`
- `factory-light/03_GOVERNANCE_VALIDATION_AND_UPDATES.md` — `e424605d9fcd714185991577b4b562994864ded4fa9ef6febb7a30c662997db5`
- `factory-light/FACTORY_INSTRUCTIONS_LIGHT.txt` — `d4bf66f9a86823e68b79374a84a12aeef374c19b794d8aa82d03f1f503b61b5b`
- `setup/CHATGPT_INSTALLATION.md` — `69064e055ea6f6b36e46452f9225bd16d1efa40f2cdb89a0e0022b176625dcb6`
- `setup/CLAUDE_INSTALLATION.md` — `4c2b9a5a838fa5ff239c006323db3285c9d5d0f49383fa64e604bb00f49d2d5e`
- `setup/CROSS_PLATFORM_TEST_PROMPTS.md` — `23cb59332c64ae333a8b1ced024dd91514abee67c64da5306b8e0f32e980768a`
- `setup/DEPLOYMENT_RECEIPT.md` — `cfc419dc628a053c88d3a47f27b94668bda899de81cde8c016a8c2086538b572`
- `setup/EDITION_SELECTION_AND_MIGRATION.md` — `c2593b75415dd2adb723bf4c1b8cc6c8f8171bd2cf0e57d383775f42288b8f86`
- `setup/GEMINI_INSTALLATION.md` — `e5b6312d78687d7d3284a7d059de9b732ccca41627a6b58294f2c65cee9b2220`
- `setup/GROK_INSTALLATION.md` — `2b9d66f49be67d5367d3cea080a69e8d3448b78c6f70bd9ad12eb355177b6749`
- `setup/MICROSOFT_INSTALLATION.md` — `77164c6e4a81ccaa4332e71aa3579ce0db4cc8971fdbf85618609fae407093e1`
- `setup/QUICK_PLATFORM_MATRIX.md` — `b4f32725357020700f55af1a20a2692b38d9f1c41dc7dd119fb9482d5f33405f`
