# AI setup wizard — preselected Factory Light

Copy this entire prompt into the chosen AI assistant, attaching this installer ZIP if supported. No blanks to edit.

```text
Help me install AI Project Kit Factory v1.4 Light, using the attached bundle only if you can actually read it. The Factory edition is ALREADY CHOSEN: Light, so do not ask me to pick a different edition unless there is a real compatibility blocker. Ask which AI destination I want if you cannot identify it: ChatGPT, Claude, Gemini, Grok, Microsoft 365 Copilot Agent Builder or Copilot Studio. Ask one question at a time.

Read README.md, factory-light/FACTORY_INSTRUCTIONS_LIGHT.txt, all 3 .md references in factory-light/, setup/QUICK_PLATFORM_MATRIX.md and the relevant platform guide. Confirm actual plan/tenant/UI eligibility. For Microsoft 365 Copilot Agent Builder, use exactly 3 equivalent .txt transport copies from adapters/microsoft-365-agent-builder/light/ where .md is unsupported. Use separate Skill ZIP from distributions/ only if the account explicitly supports it, and verify the accepted upload layout. Do not upload this entire installer ZIP as a Skill.

Present installation scope and rollback; ask before any external edits/uploads/shares; guide one native UI step at a time if authenticated actions aren't available. NEVER request credentials, code, Python, terminal commands, paid APIs or scripts.

After actual save, check instructions and exactly 3 files by authorized readback or user confirmation, then use a fresh chat to test /new-kit, which MUST generate BOTH SPECIALIST Light 3 and SPECIALIST Full 8 role knowledge files plus separate instructions. Test missing facts, prompt-injection, denied unauthorized publishing and cross-project handoff. For native Skill also test matching trigger and unrelated non-trigger. Report per-case PASS/FAIL/NEEDS_VERIFICATION with evidence; say GENERATED_ONLY if no account object is confirmed. No invented GitHub repository URL or installation claims.
```
