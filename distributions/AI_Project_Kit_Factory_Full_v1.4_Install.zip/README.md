# AI Project Kit Factory v1.4 — Full install bundle

This standalone ZIP installs **Factory Full**, containing exactly **8 Factory Markdown knowledge files** under `factory-full/` and one separately pasteable `factory-full/FACTORY_INSTRUCTIONS_FULL.txt`. It is **not** a published GitHub repo, installed AI agent, or enabled Skill. Follow `AI_SETUP_PROMPT.md` for conversational setup or `setup/QUICK_PLATFORM_MATRIX.md` for manual installation.

**IMPORTANT:** This Full Factory still generates BOTH **specialist Light (3)** and **specialist Full (8)** kits for every role; this package is not an example specialist kit. To switch *Factory installation edition*, download the combined v1.4 release and replace the knowledge set. Never mix the two editions in one persistent workspace.

Native Skills are **optional**, separately imported objects. The matching Claude-wrapped and root-form packages are in `distributions/` and may be unavailable based on account/tenant settings. Microsoft Agent Builder-compatible `.txt` knowledge copies are in `adapters/microsoft-365-agent-builder/full/`. A human must authorize all account changes and confirm live installation/behavior. No user scripts, API keys or CLI required.
