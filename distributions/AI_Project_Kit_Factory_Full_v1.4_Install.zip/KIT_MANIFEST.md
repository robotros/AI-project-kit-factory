# Factory Full v1.4 standalone installer manifest

Every path is relative to this installer archive root. The manifest excludes its own hash.

- `AI_SETUP_PROMPT.md` — `ba1f8eb47f027a6192f75e095332b1d827eb0abd4502f7a4098cb82f09c3b072`
- `README.md` — `7ae043c0dce3807efb7805c57bae12a9703635516712d6cfce34f056942cdcf4`
- `adapters/microsoft-365-agent-builder/full/01_FACTORY_CHARTER.txt` — `91e9894c2d8300a500d05b3afac3913e57fc8f3e4e69d0e870ff1b3c59cd836d`
- `adapters/microsoft-365-agent-builder/full/02_DISCOVERY_AND_ARCHITECTURE.txt` — `fe7cba6eef1c309588bfe1595b0af3c407a63e705ac719b8e162b8c9ae369afb`
- `adapters/microsoft-365-agent-builder/full/03_PLATFORM_PROFILES.txt` — `311ff633d5086693120aacf8bc8d8ca0e76349b4b34704b96a5e3c6d7bb6ac44`
- `adapters/microsoft-365-agent-builder/full/04_GENERATION_STANDARDS.txt` — `f46e389df86374f2a5935d82c1cc0558201a7fdcd29d24c77a4c3ee39cd522e6`
- `adapters/microsoft-365-agent-builder/full/05_PROMPT_ENGINEERING.txt` — `533137884f88ba6dfa40aa1709356d5d0ecf75cb44f0650ecccd4071919f4cee`
- `adapters/microsoft-365-agent-builder/full/06_SETUP_ORCHESTRATION.txt` — `65501afb92e2e3952bf10fe72854d03e10c60cc86eadf543644cf61099016fa3`
- `adapters/microsoft-365-agent-builder/full/07_VALIDATION_AND_EVALS.txt` — `e2b16c00e5ed6409cc61b74f9a40f34e71536068612cb9fc6132a7c75f0be2fc`
- `adapters/microsoft-365-agent-builder/full/08_GOVERNANCE_AND_UPDATES.txt` — `cd5cd87671d83057de9c2dcb9b9fa81a40b1d7abf7fc022e37d60b2da24c6044`
- `distributions/AI_Project_Kit_Factory_Full_Claude_Skill_v1.4.zip` — `c9e70b6ebbfc32e623867b2c64bc18ebbab86086292f1b420ee3df1a5c23d339`
- `distributions/AI_Project_Kit_Factory_Full_Root_Skill_v1.4.zip` — `92bd44f851138ee655386c702cbc49097d114f277e6a7483d0a77e48321a645d`
- `docs/OFFICIAL_SOURCES.md` — `b600e840854474b12bef944eea0a9776cd2f1d944fd4f91ba8eaedbc0d8be4c5`
- `factory-full/01_FACTORY_CHARTER.md` — `91e9894c2d8300a500d05b3afac3913e57fc8f3e4e69d0e870ff1b3c59cd836d`
- `factory-full/02_DISCOVERY_AND_ARCHITECTURE.md` — `fe7cba6eef1c309588bfe1595b0af3c407a63e705ac719b8e162b8c9ae369afb`
- `factory-full/03_PLATFORM_PROFILES.md` — `311ff633d5086693120aacf8bc8d8ca0e76349b4b34704b96a5e3c6d7bb6ac44`
- `factory-full/04_GENERATION_STANDARDS.md` — `f46e389df86374f2a5935d82c1cc0558201a7fdcd29d24c77a4c3ee39cd522e6`
- `factory-full/05_PROMPT_ENGINEERING.md` — `533137884f88ba6dfa40aa1709356d5d0ecf75cb44f0650ecccd4071919f4cee`
- `factory-full/06_SETUP_ORCHESTRATION.md` — `65501afb92e2e3952bf10fe72854d03e10c60cc86eadf543644cf61099016fa3`
- `factory-full/07_VALIDATION_AND_EVALS.md` — `e2b16c00e5ed6409cc61b74f9a40f34e71536068612cb9fc6132a7c75f0be2fc`
- `factory-full/08_GOVERNANCE_AND_UPDATES.md` — `cd5cd87671d83057de9c2dcb9b9fa81a40b1d7abf7fc022e37d60b2da24c6044`
- `factory-full/FACTORY_INSTRUCTIONS_FULL.txt` — `f8245965d22f90efe673d6cbf64f98efbd08cb3293d1d7d88d2accc031bded54`
- `setup/CHATGPT_INSTALLATION.md` — `69064e055ea6f6b36e46452f9225bd16d1efa40f2cdb89a0e0022b176625dcb6`
- `setup/CLAUDE_INSTALLATION.md` — `4c2b9a5a838fa5ff239c006323db3285c9d5d0f49383fa64e604bb00f49d2d5e`
- `setup/CROSS_PLATFORM_TEST_PROMPTS.md` — `23cb59332c64ae333a8b1ced024dd91514abee67c64da5306b8e0f32e980768a`
- `setup/DEPLOYMENT_RECEIPT.md` — `cfc419dc628a053c88d3a47f27b94668bda899de81cde8c016a8c2086538b572`
- `setup/EDITION_SELECTION_AND_MIGRATION.md` — `c2593b75415dd2adb723bf4c1b8cc6c8f8171bd2cf0e57d383775f42288b8f86`
- `setup/GEMINI_INSTALLATION.md` — `e5b6312d78687d7d3284a7d059de9b732ccca41627a6b58294f2c65cee9b2220`
- `setup/GROK_INSTALLATION.md` — `2b9d66f49be67d5367d3cea080a69e8d3448b78c6f70bd9ad12eb355177b6749`
- `setup/MICROSOFT_INSTALLATION.md` — `77164c6e4a81ccaa4332e71aa3579ce0db4cc8971fdbf85618609fae407093e1`
- `setup/QUICK_PLATFORM_MATRIX.md` — `b4f32725357020700f55af1a20a2692b38d9f1c41dc7dd119fb9482d5f33405f`
